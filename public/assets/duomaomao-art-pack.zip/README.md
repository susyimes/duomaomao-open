# 风铃岛原创素材包

模型、贴图、音效位于 public/assets。GLB 可以导入 Blender 等支持 glTF 的工具。

可编辑源码位于 src/lib/duomaomao/assets。使用 Node.js 24 或更新版本，运行 npm install 和 npm run generate 可重新生成模型、动画和音效。草地 PNG 保持为随包提供的图像；生成提示词见 PROVENANCE.md。

角色动画：idle / walk / celebrate。采用刚性部件层级，未提供蒙皮变形骨架。地图尺寸单位为米。贴图需单独指定给 meadow_grass 材质。

许可见 public/assets/ASSET-LICENSE.txt。这个包不包含上游 Messenger 的素材。
